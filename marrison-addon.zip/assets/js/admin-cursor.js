jQuery(document).ready(function($){
    $('.marrison-color-field').wpColorPicker();
});

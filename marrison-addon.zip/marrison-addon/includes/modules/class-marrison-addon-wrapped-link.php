<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Marrison_Addon_Wrapped_Link {

	public function __construct() {
		add_action( 'elementor/element/container/section_layout/after_section_end', [ $this, 'register_controls' ] );
		add_action( 'elementor/frontend/container/before_render', [ $this, 'before_render' ] );
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'register_controls' ] );
		add_action( 'elementor/frontend/widget/before_render', [ $this, 'before_render' ] );
	}

	public function register_controls( $element ) {
		$element->start_controls_section(
			'section_marrison_addon',
			[
				'label' => esc_html__( 'Wrapped Link', 'marrison-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'marrison_addon_url',
			[
				'label' => esc_html__( 'Link', 'marrison-addon' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'marrison-addon' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$element->end_controls_section();
	}

	public function before_render( $element ) {
		if ( Marrison_Addon_Context::is_elementor_editor_context() ) {
			return;
		}

		$settings = $element->get_settings_for_display();

		if ( ! empty( $settings['marrison_addon_url']['url'] ) && '#' !== trim( $settings['marrison_addon_url']['url'] ) ) {
			$this->enqueue_scripts();
			$element->add_render_attribute( '_wrapper', 'data-marrison-addon', wp_json_encode( $settings['marrison_addon_url'] ) );
			$element->add_render_attribute( '_wrapper', 'style', 'cursor: pointer;' );
			if ( ! empty( $settings['marrison_addon_url']['custom_attributes'] ) ) {
				$attributes = \Elementor\Utils::parse_custom_attributes( $settings['marrison_addon_url']['custom_attributes'] );
				foreach ( $attributes as $name => $value ) {
					// Keep the module's navigation configuration and Elementor identity intact.
					if ( 'data-marrison-addon' !== $name && 'data-settings' !== $name && 'data-id' !== $name ) {
						$element->add_render_attribute( '_wrapper', $name, $value );
					}
				}
			}
		}
	}

	public function enqueue_scripts() {
		$plugin_root_file = Marrison_Addon::plugin_file();
		wp_enqueue_script( 'marrison-addon', plugins_url( 'assets/js/marrison-addon.js', $plugin_root_file ), [], Marrison_Addon::asset_version( 'assets/js/marrison-addon.js' ), true );
	}
}

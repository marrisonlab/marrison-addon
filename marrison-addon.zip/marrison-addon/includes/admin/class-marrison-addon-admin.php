<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Marrison_Addon_Admin {

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_styles' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'wp_ajax_marrison_save_option', [ $this, 'ajax_save_option' ] );
		add_action( 'admin_head', [ $this, 'add_menu_badge_styles' ] );
	}

	public function enqueue_styles( $hook ) {
		if ( ! $this->is_marrison_admin_page() ) {
			return;
		}
		// Point to the root plugin file to get the correct base URL
		$plugin_root_file = dirname( dirname( dirname( __FILE__ ) ) ) . '/marrison-addon.php';
		wp_enqueue_style( 'marrison-admin-css', plugins_url( 'assets/css/admin.css', $plugin_root_file ), [], Marrison_Addon::VERSION );
	}

	public function enqueue_scripts( $hook ) {
		if ( ! $this->is_marrison_admin_page() ) {
			return;
		}
		$plugin_root_file = dirname( dirname( dirname( __FILE__ ) ) ) . '/marrison-addon.php';
		wp_enqueue_script( 'marrison-admin-global', plugins_url( 'assets/js/admin-global.js', $plugin_root_file ), [ 'jquery' ], Marrison_Addon::VERSION, true );
		
		wp_localize_script( 'marrison-admin-global', 'marrison_global', [
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'marrison_save_option_nonce' ),
			'error_saving' => __( 'Errore durante il salvataggio delle impostazioni', 'marrison-addon' ),
			'connection_error' => __( 'Errore di connessione', 'marrison-addon' ),
		] );
	}

	private function is_marrison_admin_page() {
		if ( ! isset( $_GET['page'] ) ) {
			return false;
		}

		$page = sanitize_key( wp_unslash( $_GET['page'] ) );

		if ( 'marrison_addon_panel' === $page || 0 === strpos( $page, 'marrison_addon_' ) ) {
			return true;
		}

		return in_array(
			$page,
			[
				'marrison-cookie',
				'marrison-video-thumb',
			],
			true
		);
	}

	public function ajax_save_option() {
		check_ajax_referer( 'marrison_save_option_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Permission denied' ] );
		}

		$option_name = isset( $_POST['option_name'] ) ? sanitize_text_field( $_POST['option_name'] ) : '';
		$value       = isset( $_POST['value'] ) ? $_POST['value'] : null;

		if ( empty( $option_name ) ) {
			wp_send_json_error( [ 'message' => 'Missing option name' ] );
		}

		$allowed_options = apply_filters(
			'marrison_addon/ajax_save_allowed_options',
			[
				'marrison_addon_modules',
				'marrison_addon_disabled_sizes',
			]
		);

		if ( ! in_array( $option_name, $allowed_options, true ) ) {
			wp_send_json_error( [ 'message' => 'Invalid option name' ] );
		}

		// Handle array updates if key is provided
		$key = isset( $_POST['key'] ) ? sanitize_text_field( $_POST['key'] ) : null;
		
		if ( $key !== null ) {
			$current_value = get_option( $option_name, [] );
			if ( ! is_array( $current_value ) ) {
				$current_value = [];
			}
			
			// Boolean handling for checkboxes/switches
			if ( $value === 'true' || $value === '1' ) {
				$current_value[ $key ] = 1;
			} else {
				$current_value[ $key ] = 0; // Or unset if preferred, but 0 is safer for checkboxes
			}
			
			update_option( $option_name, $current_value );

			if ( 'marrison_addon_modules' === $option_name ) {
				if ( 'browser_cache' === $key && empty( $current_value[ $key ] ) ) {
					$this->cleanup_browser_cache_server_rules();
				}

				do_action( 'marrison_addon/module_status_changed', $key, ! empty( $current_value[ $key ] ) );
			}
		} else {
			update_option( $option_name, $value );
		}

		wp_send_json_success( [ 'message' => 'Settings saved' ] );
	}

	private function cleanup_browser_cache_server_rules() {
		$server_file = dirname( __DIR__ ) . '/modules/browser-cache/class-browser-cache-server.php';

		if ( ! file_exists( $server_file ) ) {
			return;
		}

		require_once $server_file;

		if ( ! class_exists( 'Marrison_Addon_Browser_Cache_Server' ) ) {
			return;
		}

		$server = new Marrison_Addon_Browser_Cache_Server();
		$result = $server->remove_htaccess_rules();

		if ( is_wp_error( $result ) ) {
			$server->update_state(
				[
					'status'  => 'error',
					'message' => $result->get_error_message(),
				]
			);
		}
	}

	public function add_admin_menu() {
		// Main Menu - Dashboard
		add_menu_page(
			esc_html__( 'Marrison Addon', 'marrison-addon' ),
			esc_html__( 'AM Addon', 'marrison-addon' ),
			'manage_options',
			'marrison_addon_panel',
			[ $this, 'dashboard_page_html' ],
			'dashicons-admin-generic',
			31
		);
	}

	public function register_settings() {
		register_setting( 'marrison_addon_settings', 'marrison_addon_modules' );
	}

	public function add_menu_badge_styles() {
        $icon_url = plugin_dir_url(__FILE__) . '../../assets/icon.svg';
        ?>
        <style>
        #toplevel_page_marrison_addon_panel .wp-menu-image:before { display: none; }
        #toplevel_page_marrison_addon_panel .wp-menu-image {
            background-color: currentColor;
            -webkit-mask-image: url('<?php echo esc_url($icon_url); ?>');
            mask-image: url('<?php echo esc_url($icon_url); ?>');
            -webkit-mask-repeat: no-repeat;
            mask-repeat: no-repeat;
            -webkit-mask-position: center;
            mask-position: center;
            -webkit-mask-size: 20px;
            mask-size: 20px;
        }
        </style>
        <?php
    }

	public function dashboard_page_html() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$modules = get_option( 'marrison_addon_modules', [] );
		$is_elementor_active = did_action( 'elementor/loaded' );
		$is_woocommerce_active = Marrison_Addon::is_woocommerce_active();
		$is_jet_engine_active = Marrison_Addon::is_jet_engine_active();

		$available_modules = Marrison_Addon::get_module_definitions();
		uasort(
			$available_modules,
			static function ( $a, $b ) {
				$title_a = isset( $a['title'] ) ? remove_accents( wp_strip_all_tags( (string) $a['title'] ) ) : '';
				$title_b = isset( $b['title'] ) ? remove_accents( wp_strip_all_tags( (string) $b['title'] ) ) : '';

				return strnatcasecmp( $title_a, $title_b );
			}
		);
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Marrison Addon', 'marrison-addon' ); ?></h1>
			<p><?php echo esc_html__( 'Benvenuto in Marrison Addon. Gestisci i tuoi moduli qui sotto.', 'marrison-addon' ); ?></p>
			
			<div class="marrison-modules-grid">
				<?php foreach ( $available_modules as $id => $module ) :
					$checked = isset( $modules[ $id ] ) && $modules[ $id ] ? 'checked' : '';
					$reload = isset( $module['reload'] ) && $module['reload'] ? 'true' : 'false';
					$icon = isset( $module['icon'] ) ? $module['icon'] : 'dashicons-admin-generic';
					
					$is_disabled = false;
					$disabled_attr = '';
					$card_style = '';
					$badge = '';

					$missing_requirements = [];

					if ( isset( $module['requires_elementor'] ) && $module['requires_elementor'] && ! $is_elementor_active ) {
						$missing_requirements[] = esc_html__( 'Elementor', 'marrison-addon' );
					}

					if ( isset( $module['requires_woocommerce'] ) && $module['requires_woocommerce'] && ! $is_woocommerce_active ) {
						$missing_requirements[] = esc_html__( 'WooCommerce', 'marrison-addon' );
					}

					if ( isset( $module['requires_jet_engine'] ) && $module['requires_jet_engine'] && ! $is_jet_engine_active ) {
						$missing_requirements[] = esc_html__( 'JetEngine', 'marrison-addon' );
					}

					if ( ! empty( $missing_requirements ) ) {
						$is_disabled = true;
						$disabled_attr = 'disabled';
						$card_style = 'style="opacity: 0.6; filter: grayscale(100%); pointer-events: none;"';
						$badge = '<span class="marrison-badge-error">' . sprintf(
							/* translators: %s: Missing plugin names. */
							esc_html__( 'Richiede %s', 'marrison-addon' ),
							esc_html( implode( ' + ', $missing_requirements ) )
						) . '</span>';
					}
				?>
				<div class="marrison-module-card" <?php echo $card_style; ?>>
					<div class="marrison-card-header">
						<div class="marrison-card-heading">
							<span class="dashicons <?php echo esc_attr( $icon ); ?> marrison-card-icon" aria-hidden="true"></span>
							<h3 class="marrison-card-title"><?php echo esc_html( $module['title'] ); ?></h3>
						</div>
						<label class="marrison-switch">
							<input type="checkbox" 
								   class="marrison-ajax-toggle" 
								   data-option="marrison_addon_modules" 
								   data-key="<?php echo esc_attr( $id ); ?>" 
								   data-reload="<?php echo esc_attr( $reload ); ?>"
								   <?php echo $checked; ?>
								   <?php echo $disabled_attr; ?>>
							<span class="marrison-slider"></span>
						</label>
					</div>
					<p class="marrison-card-desc"><?php echo esc_html( $module['desc'] ); ?></p>
					<?php if ( ! empty( $badge ) ) : ?>
						<div style="margin-top: 10px;"><?php echo $badge; ?></div>
					<?php endif; ?>
					<?php if ( empty( $is_disabled ) && ! empty( $checked ) && ! empty( $module['settings_page'] ) ) : ?>
						<p style="margin: 14px 0 0;">
							<a class="button button-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=' . sanitize_key( $module['settings_page'] ) ) ); ?>">
								<?php echo esc_html__( 'Impostazioni', 'marrison-addon' ); ?>
							</a>
						</p>
					<?php endif; ?>
				</div>
				<?php endforeach; ?>
			</div>

		</div>
		<?php
	}
}
